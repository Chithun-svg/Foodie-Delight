// JavaScript for interactive behavior
document.addEventListener("DOMContentLoaded", () => {
    const toggleButtons = document.querySelectorAll(".toggle-button");

    toggleButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const details = button.nextElementSibling;
            details.style.display =
                details.style.display === "none" || !details.style.display
                    ? "block"
                    : "none";
            button.textContent = details.style.display === "block" ? "View Less" : "View More";
        });
    });
});
