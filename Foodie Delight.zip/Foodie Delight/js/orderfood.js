const cart = [];

function addToCart(item, price) {
    cart.push({ item, price });
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    const totalPriceElement = document.getElementById('total-price');

    cartItems.innerHTML = '';
    let total = 0;

    cart.forEach(({ item, price }) => {
        const li = document.createElement('li');
        li.textContent = `${item} - $${price.toFixed(2)}`;
        cartItems.appendChild(li);
        total += price;
    });

    totalPriceElement.textContent = `Total: $${total.toFixed(2)}`;
}

function checkout() {
    if (cart.length === 0) {
        alert('Your cart is empty! Please add items before checking out.');
        return;
    }

    alert('Thank you for your order! Your food will be delivered shortly.');
    cart.length = 0; // Clear the cart
    updateCart();
}