document.getElementById("contactForm").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent form from refreshing the page

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const phone = document.getElementById("phone").value.trim();

    // Email validation
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (!email.match(emailPattern)) {
        alert("Please enter a valid email address.");
        return;
    }

    // Phone number validation
    const phonePattern = /^[0-9]{10}$/;
    if (!phone.match(phonePattern)) {
        alert("Please enter a valid 10-digit phone number.");
        return;
    }

    // Show success message
    document.getElementById("successMessage").style.display = "block";
    document.getElementById("contactForm").reset();
});
