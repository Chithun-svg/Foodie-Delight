// JavaScript for Home Page

document.addEventListener("DOMContentLoaded", () => {
    console.log("Welcome to the Home Page!");

    // Example: Adding a dynamic greeting
    const introSection = document.querySelector(".intro p");
    const currentHour = new Date().getHours();
    let greeting;

    if (currentHour < 12) {
        greeting = "Good Morning! Explore our delicious recipes.";
    } else if (currentHour < 18) {
        greeting = "Good Afternoon! Check out our features below.";
    } else {
        greeting = "Good Evening! Relax and browse our website.";
    }

    introSection.textContent = greeting;
});
